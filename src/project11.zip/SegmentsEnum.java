/**
 * * Author : Abdelmajid ID ALI
 * * On : 07/03/2022
 * * Email :  abdelmajid.idali@gmail.com
 **/
public enum SegmentsEnum {
    CONSTANT, ARGUMENT, LOCAL,
    STATIC, THIS, THAT, POINTER, TEMP
}
