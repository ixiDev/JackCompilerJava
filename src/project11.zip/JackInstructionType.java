/**
 * * Author : Abdelmajid ID ALI
 * * On : 02/03/2022
 * * Email :  abdelmajid.idali@gmail.com
 **/
public enum JackInstructionType {
    KEYWORD, SYMBOL, IDENTIFIER,
    INTEGER_CONSTANT, STRING_CONSTANT, UNKNOWN
}
